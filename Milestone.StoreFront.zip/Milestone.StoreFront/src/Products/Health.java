package Products;

public class Health extends Product
{
	private int healingAmount;
	/**
	 * 
	 * @param name
	 * @param description
	 * @param price
	 * @param quantity
	 * @param healingAmount
	 */
	public Health(String name, String description, double price, int quantity, int healingAmount)
	{
		super(name, description, price, quantity);
		this.healingAmount = healingAmount;
	}
	/**
	 * 
	 * @return
	 */
	public int getHealingAmount()
	{
		return healingAmount;
	}
	/**
	 * 
	 */
	@Override
	public String toString()
	{
		return super.toString() + "  Healing Amount: " + healingAmount + "\n";
		
	}
}
